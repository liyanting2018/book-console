app_name = 'book-console';

api_host = 'http://localhost:8080';

static_app_host = 'http://localhost:8080';

api_endpoint = api_host + '';

sso_page_path = '/sso.html';

default_state = 'home';
